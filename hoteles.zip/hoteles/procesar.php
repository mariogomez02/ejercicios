<?php

$cantidad = $_POST["cantidad"];

$total = 1500 * $cantidad;
if($cantidad>5){
    $des = $total *0.1;
    $total = $total - $des;
    echo "El total a pagar es de ".$total. " pesos";
}else
{
    echo "El total a pagar es de ".$total. " pesos";
}

?>